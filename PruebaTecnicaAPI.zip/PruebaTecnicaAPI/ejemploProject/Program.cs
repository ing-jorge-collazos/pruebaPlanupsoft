using API.Users.Services.Core.Jwt;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using SIGPRO.Services;
using SIGPRO.Services.Core.Users;
using System.Text;

var builder = WebApplication.CreateBuilder(args);
IConfiguration configuration;
// Add services to the container.


var config = builder.Configuration;
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen(c =>
        { 
           c.SwaggerDoc("v1", new OpenApiInfo { Title = "APICore SIGPRO", Version = "v1" });
            c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
            {
                Description = "JWT Autorization Schema. \r\n\r\n Write 'Bearer [Space] and Write the token'",
                Name="Authorization",
                In = ParameterLocation.Header,
                Type = SecuritySchemeType.ApiKey,
                Scheme ="Bearer"
            });

            c.AddSecurityRequirement(new OpenApiSecurityRequirement()
            { 
                {
                new OpenApiSecurityScheme
                {
                    Reference = new OpenApiReference
                    {
                        Type = ReferenceType.SecurityScheme,
                        Id = "Bearer"
                    },

                    Scheme = "oauth2",
                    Name = "Bearer",
                    In= ParameterLocation.Header,
                },
                new List<string>()
            }
            });
               
        }); 

        

builder.Services.AddSingleton<IServiceUserApi, ServiceUserApi>();
builder.Services.AddSingleton<IServiceUser, ServiceUser>();
builder.Services.AddTransient<DataConnectionContext>();

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters()
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidIssuer = config["settingsjwt:Issuer"],
        ValidAudience = config["settingsjwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(
        Encoding.UTF8.GetBytes(config["settingsjwt:SecretKey"])) //Aqui se deberia ir a la base de datos y tomar la clave del usuario que esta haciendo la peticion


    };
});
builder.Services.AddControllers();
builder.Services.AddAuthorization();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
