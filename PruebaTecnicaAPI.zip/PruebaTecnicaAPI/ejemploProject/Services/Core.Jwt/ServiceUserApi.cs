﻿using API.Users.Services.Core.Jwt.Models;
using API.Users.Services.Core.Users.Models;
using Dapper;
using Microsoft.IdentityModel.Abstractions;
using SIGPRO.Services;
using System.Data;
using System.Reflection.Metadata.Ecma335;

namespace API.Users.Services.Core.Jwt
{
    public class ServiceUserApi : IServiceUserApi
    {
        private readonly DataConnectionContext context;
        public ServiceUserApi(DataConnectionContext context)
        {
            this.context = context;
        }



        public async Task<ModelGetUserApi> Login(ModelApi login)
        {
            ModelGetUserApi user = null;
            try
            {
                using (var connection = context.CreateConnection())
                {
                    
                    var param = new DynamicParameters();
                    param.Add("@UsuarioApi", login.userApi, DbType.String, ParameterDirection.Input, 500);
                    param.Add("@PasswordApi", login.passwordApi, DbType.String, ParameterDirection.Input, 500);
                    user = await connection.QueryFirstOrDefaultAsync<ModelGetUserApi>("dbo.SpGetUsersApi", param, commandType: CommandType.StoredProcedure);

                }
            }
            catch(Exception ex)
            {
                throw new Exception("Se ha producido un error al obtener datos del usuario" + ex.Message);

            }

            return user;
        }
        
    }
}
