﻿using API.Users.Services.Core.Jwt.Models;

namespace API.Users.Services.Core.Jwt
{
    public interface IServiceUserApi
    {
        Task<ModelGetUserApi> Login(ModelApi login);
    }
}
