﻿namespace API.Users.Services.Core.Jwt.Models
{
    //Clase para hacer login, comunicacion con la DB
    public class ModelApi
    {
        public string userApi { get; set; }
        public string passwordApi { get; set; }

    }
}
