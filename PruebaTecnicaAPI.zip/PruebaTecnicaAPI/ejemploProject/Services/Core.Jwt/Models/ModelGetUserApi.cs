﻿namespace API.Users.Services.Core.Jwt.Models
{
    //clase que permite validar si el login se hizo correctamente, se devuleve el Token
    public class ModelGetUserApi
    {
        public string userName { get; set; }
        public string email { get; set; }
        public string token { get; set; }
    }
}
