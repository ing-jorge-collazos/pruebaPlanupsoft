﻿namespace API.Users.Services.Core.Jwt.DTO
{
    public class UserApiDTO
    {
        public string userName { get; set; }
        public string token { get; set; }
    }
}
