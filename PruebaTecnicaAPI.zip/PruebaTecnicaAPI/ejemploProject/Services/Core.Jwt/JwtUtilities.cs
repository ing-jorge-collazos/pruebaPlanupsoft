﻿using API.Users.Services.Core.Jwt.DTO;
using API.Users.Services.Core.Jwt.Models;
using API.Users.Services.Core.Users.Models;
using SIGPRO.Services.Core.Users.DTO;

namespace API.Users.Services.Core.Jwt
{
    public static class JwtUtilities
    {

        public static UserApiDTO convertToDTO(this ModelGetUserApi e)
        {
            if (e != null)
            {
                return new UserApiDTO
                {
                    userName = e.userName,
                    token = e.token
                    
                };

            }
            return null;
        }

    }
}
