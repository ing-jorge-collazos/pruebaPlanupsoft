﻿using System.Data;
using System.Data.SqlClient;

namespace SIGPRO.Services
{
    public class DataConnectionContext
    {
        private readonly IConfiguration _configuration;
        private readonly string connectionstring;

        public DataConnectionContext(IConfiguration configuration)
        {
            _configuration = configuration;
            connectionstring = _configuration.GetConnectionString("connectiondb");

        }
        public IDbConnection CreateConnection() => new SqlConnection(connectionstring);



    }
}
