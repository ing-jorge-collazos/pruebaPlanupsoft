﻿using System.ComponentModel.DataAnnotations;

namespace SIGPRO.Services.Core.Users.DTO
{
    public class UsersDTO
    {
        [Required(ErrorMessage = "Campo requerido")]
        [StringLength(100, MinimumLength = 4, ErrorMessage = "La longitud del texto debe estar ebtre 1 y 100 caracteres")]
        [RegularExpression("^[a-zA-Z ]+$", ErrorMessage = "Solo se permiten Letras y espacios")]
        public string userName { get; set; }

        [Required(ErrorMessage = "Campo requerido")]
        [RegularExpression("^[0-9]+$", ErrorMessage = "El codigo es un campo numerico")]
        [MaxLength(10, ErrorMessage = "El codigo tiene maximo 10 digitos")]
        public string userCode { get; set; }

        [Required(ErrorMessage = "Campo requerido")]
        [EmailAddress(ErrorMessage = "Formato de correo invalido")]
        public string userEmail { get; set; }

        [Required(ErrorMessage = "Campo requerido")]
        [RegularExpression("^[0-9]+$", ErrorMessage = "La edad es un valor numerico")]
        [Range(18, 50, ErrorMessage = "La edad debe estar entre los 18 y 50 años")]
        public int userAge { get; set; }

    }
}

