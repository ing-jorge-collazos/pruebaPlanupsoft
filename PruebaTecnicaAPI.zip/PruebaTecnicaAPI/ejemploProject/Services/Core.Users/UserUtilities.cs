﻿using API.Users.Services.Core.Jwt.DTO;
using API.Users.Services.Core.Users.Models;
using SIGPRO.Services.Core.Users.DTO;

namespace SIGPRO.Services.Core.Users
{

    public static class CoreUserUtilities
    {
        //Se realiza la conversion para la visualizacion de los Datos
        //que unicamente vera el usuario que consuma el API

        public static UsersDTO convertToDTO(this ModelUser e)
        {
            if (e != null)
            {
                return new UsersDTO
                {
                    userName = e.userName,
                    userCode = e.userCode,
                    userEmail = e.userEmail,
                    userAge = e.userAge
                };

            }
            return null;
        }


        

    }
}

