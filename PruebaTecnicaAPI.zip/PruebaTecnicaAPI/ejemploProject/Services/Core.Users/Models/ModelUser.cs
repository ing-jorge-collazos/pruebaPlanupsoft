﻿namespace API.Users.Services.Core.Users.Models
{
    public class ModelUser
    {
        public int Id { get; init; }
        
        public string userCode { get; set; }
        public string userEmail { get; set; }
        public int userAge { get; set; }
        public DateTime dateSingUp { get; set; }
        public DateTime deleteLogin { get; set; }
    }
}
