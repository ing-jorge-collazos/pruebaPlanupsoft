﻿using API.Users.Services.Core.Users.Models;
using Dapper;
using System.Data;

namespace SIGPRO.Services.Core.Users
{
    public class ServiceUser : IServiceUser
    {
        private readonly DataConnectionContext context;
        public ServiceUser(DataConnectionContext context)
        {
            this.context = context;
        }

        //Metodo que implementa el registro de usuarios
        public async Task NewUser(ModelUser userNew)
        {
            try
            {
                using (var connection = context.CreateConnection())
                {

                    var param = new DynamicParameters();
                    param.Add("@UserName", userNew.userName, DbType.String, ParameterDirection.Input, 200);
                    param.Add("@UserCode", userNew.userCode, DbType.String, ParameterDirection.Input, 10);
                    param.Add("@UserEmail", userNew.userEmail, DbType.String, ParameterDirection.Input, 255);
                    param.Add("@UserAge", userNew.userAge, DbType.Int32, ParameterDirection.Input);
                    param.Add("@dateSignUp", userNew.dateSingUp, DbType.DateTime, ParameterDirection.Input);

                    //Se indica via Dapper en que StoreProcedure se ejecuta
                    await connection.ExecuteScalarAsync("dbo.SpNewUsers", param, commandType: CommandType.StoredProcedure);

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al registrar el usuario" + ex.Message);

            }

        }
        //Metodo que implementa obtener un usuario por codigo
        public async Task<ModelUser> GetUser(string userCode)
        {
            ModelUser queryUser = null;
            try
            {
                using (var connection = context.CreateConnection())
                {

                    var param = new DynamicParameters();
                    param.Add("@UserCode", userCode, DbType.String, ParameterDirection.Input, 10);
                    queryUser = await connection.QueryFirstOrDefaultAsync<ModelUser>("dbo.SpGetUsers", param, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Se ha producido un error al obtener el usuario" + ex.Message);
            }
            return queryUser;
        }

        //Metodo que implementa obtener a todos los usuarios
        public async Task<IEnumerable<ModelUser>> GetUsers()
        {
            List<ModelUser> users = new List<ModelUser>();

            try
            {
                using (var connection = context.CreateConnection())
                {
                    var param = new DynamicParameters();
                    var queryGetUsers = await connection.QueryAsync<ModelUser>("dbo.SpGetUsers", commandType: CommandType.StoredProcedure);
                    users = queryGetUsers.ToList();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al obtener a los usuarios" + ex.Message);

            }

            return users;
        }

        //Metodo que implementa alctualizar un registro
        public async Task UpdateUser(ModelUser UserToUpdate)
        {
            try
            {
                using (var connection = context.CreateConnection())
                {

                    var param = new DynamicParameters();
                    param.Add("@UserName", UserToUpdate.userName, DbType.String, ParameterDirection.Input, 200);
                    param.Add("@UserCode", UserToUpdate.userCode, DbType.String, ParameterDirection.Input, 10);
                    param.Add("@UserEmail", UserToUpdate.userEmail, DbType.String, ParameterDirection.Input, 255);
                    param.Add("@UserAge", UserToUpdate.userAge, DbType.Int32, ParameterDirection.Input);


                    //Se indica via Dapper en que StoreProcedure se ejecuta
                    await connection.ExecuteScalarAsync("dbo.SpEditUsers", param, commandType: CommandType.StoredProcedure);

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al modificar el usuario" + ex.Message);

            }
        }


        //Metodo que implementa eliminar registros
        public async Task DeleteUser(string UserToDelete)
        {
            try
            {
                using (var connection = context.CreateConnection())
                {

                    var param = new DynamicParameters();
                    param.Add("@UserCode", UserToDelete, DbType.String, ParameterDirection.Input, 10);
                    await connection.ExecuteScalarAsync("dbo.SpDeleteUsers", param, commandType: CommandType.StoredProcedure);

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al dar de baja el usuario" + ex.Message);

            }
        }

    }
}
