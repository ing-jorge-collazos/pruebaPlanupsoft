﻿using API.Users.Services.Core.Users.Models;

namespace SIGPRO.Services.Core.Users
{
    /*La interfaz permite agregar todas las operaciones que tendria el servicio de usuarios,
     * Su implementacion se realiza en la clase - ServiceUser*/

    public interface IServiceUser
    {

        public Task<IEnumerable<ModelUser>> GetUsers();

    }
}
