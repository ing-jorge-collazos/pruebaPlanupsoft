﻿using API.Users.Services.Core.Users.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SIGPRO.Services.Core.Users;
using SIGPRO.Services.Core.Users.DTO;

namespace API.Core.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [Authorize(AuthenticationSchemes =JwtBearerDefaults.AuthenticationScheme)]
    public class UserController : Controller
    {
        private readonly IServiceUser _serviceUser;

        //Defincion del constructor de la clase

        public UserController(IServiceUser serviceUser)
        {
            _serviceUser = serviceUser;
        }
          

        [HttpGet]
        [Authorize]
        public async Task<IEnumerable<UsersDTO>> GetUsers()
        {
            var UsersList = (await _serviceUser.GetUsers()).Select(a => a.convertToDTO());
            return UsersList;
        }
             

    }
}
