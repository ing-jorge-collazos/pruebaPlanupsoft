﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using SIGPRO.Services.Core.Users;
using API.Users.Services.Core.Jwt;
using API.Users.Services.Core.Jwt.DTO;
using API.Users.Services.Core.Jwt.Models;
using System.Text;
using Microsoft.AspNetCore.Authorization;


namespace API.Users.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly IServiceUserApi _serviceUserApi;
        private readonly IConfiguration configuration;

        public AuthenticationController(IServiceUserApi serviceUser, IConfiguration configuration)
        {
            _serviceUserApi = serviceUser;
            this.configuration = configuration;
        }


        [HttpPost]
        [AllowAnonymous]
        public async Task<ActionResult<UserApiDTO>>iniciosesion(ModelApi userLogin)
        {
            ModelGetUserApi user = null;
            user = await AuthenticateUserAsync(userLogin);
            if(user == null)
            {
                throw new Exception("Las credenciales ingresadas no son validas ");
            }
            else
            {
                user = GenerateTokenJWT(user);
            }
            return user.convertToDTO();
        }

        private async Task<ModelGetUserApi> AuthenticateUserAsync(ModelApi userLogin)
        {
            ModelGetUserApi user = await _serviceUserApi.Login(userLogin);
            return user;
        }

        private ModelGetUserApi GenerateTokenJWT(ModelGetUserApi userInfo)
        {
            //Header
            var _symetricSecurityKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(configuration["settingsjwt:SecretKey"])
                );

            var _signingCredentials = new SigningCredentials(
                    _symetricSecurityKey, SecurityAlgorithms.HmacSha256
                );

            var _Header = new JwtHeader(_signingCredentials);

            //Claims
            var _Claims = new[]
            {
                new Claim("userName", userInfo.userName),
                new Claim("email ",userInfo.email),
                new Claim(JwtRegisteredClaimNames.Email, userInfo.email),
            };

            //Payload
            var _Payload = new JwtPayload(
                issuer: configuration["settingsjwt:Issuer"],
                audience: configuration["settingsjwt:Audience"],
                claims: _Claims,
                notBefore: DateTime.UtcNow,
                expires: DateTime.UtcNow.AddSeconds(30)
                
                );

            //Token
            var _Token = new JwtSecurityToken(
                _Header,
                _Payload


                );
            userInfo.token = new JwtSecurityTokenHandler().WriteToken(_Token);
            return userInfo;
        }
    }
}
